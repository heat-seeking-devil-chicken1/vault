import React from "react";
import { Paper, Typogrpahy, Avatar, Box, Typography } from "@mui/material";

export function TransactionsCard() {

  return (
    <Paper
      elevation={12}
      sx={{

      }}
    >
      <Typography
        sx={{
          fontWeight: 600,
        }}
      >
        TRANSACTIONS
      </Typography>
    </Paper>
  );
}
