import React from "react";

const Footer = (props) => {
  return (
    <><div className="footer">
      <div>&copy; STABBIN RABBITS INC.</div>
      <div>All rights reserved</div>
    </div>
    </>
  );
};

export default Footer;
